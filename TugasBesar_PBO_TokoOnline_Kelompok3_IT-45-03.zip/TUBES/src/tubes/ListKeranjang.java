package tubes;

//import com.mysql.jdbc.Connection;
//import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Doni Arya
 */ 
public class ListKeranjang extends javax.swing.JFrame {

    /**
     * Creates new form ListProduct
     */
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;
//    private DefaultListModel<String> listModel;
    private String url = "jdbc:mysql://localhost:3306/tubespbo";
    private String username = "root";
    private String password = "";
    
//    public ListKeranjang() throws SQLException {
//        this.connection = (Connection) DriverManager.getConnection(url, username, password);
//        initComponents();
//    }
  
    /**
     *
     */
    public ListKeranjang() {
        try {
            this.connection = (Connection) DriverManager.getConnection(url, username, password);
            this.statement = (Statement) connection.createStatement();
            initComponents();
            fetchDataFromDatabase();
        } catch (SQLException ex) {
            // Tangani pengecualian sesuai kebutuhan Anda
            ex.printStackTrace();
        }
    }
     Dashboard d1 = new Dashboard();

//    private void initComponents() {
//        // Inisialisasi komponen GUI di sini sesuai kebutuhan Anda
//    }

    private void fetchDataFromDatabase() {
        DefaultListModel<String> namaBarang = new DefaultListModel<>();
        DefaultListModel<String> quantityBarang = new DefaultListModel<>();
        DefaultListModel<String> hrgBarang = new DefaultListModel<>();
        DefaultListModel<String> ttlBarang = new DefaultListModel<>();
        

        try {
            resultSet = statement.executeQuery("SELECT * FROM barang");

            while (resultSet.next()) {
//                System.out.println(resultSet.getString("nama_barang"));
                String nama = resultSet.getString("nama_barang");
                String quan = resultSet.getString("quantity");
                String hrg = resultSet.getString("harga");
                String ttl = resultSet.getString("total");
                
                
                namaBarang.addElement(nama);
                quantityBarang.addElement(quan);
                hrgBarang.addElement(hrg);
                ttlBarang.addElement(ttl);
            }
            
            // menampilkan data pada list
            JList<String> nBarang = new JList<>(namaBarang);
            JList<String> qBarang = new JList<>(quantityBarang);
            JList<String> hBarang = new JList<>(hrgBarang);
            JList<String> tBarang = new JList<>(ttlBarang);
            listNamaBarang.setModel(nBarang.getModel());
            listKotakHarga.setModel(hBarang.getModel());
            listKotakQuantity.setModel(qBarang.getModel());
            listKotakTotalHarga.setModel(tBarang.getModel());
            
            // menghitung banyak data
            ttlBelanja.setText(String.valueOf(nBarang.getModel().getSize()));
            
            // menghitung total belanja
            int total = 0;
                for (int i = 0; i < ttlBarang.size(); i++) {
                    total += Integer.parseInt(ttlBarang.get(i));
                }
            nomTtl.setText(String.valueOf("Rp. "+ total));

        } catch (SQLException ex) {
            // Tangani pengecualian sesuai kebutuhan Anda
//            ex.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
            } catch (SQLException ex) {
                // Tangani pengecualian sesuai kebutuhan Anda
//                ex.printStackTrace();
            }
        }
    }
    
    
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new ListKeranjang().setVisible(true);
        });
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listNamaBarang = new javax.swing.JList<>();
        namaBarangLabel = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        listKotakQuantity = new javax.swing.JList<>();
        listQuantity = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        listKotakHarga = new javax.swing.JList<>();
        listHarga = new javax.swing.JLabel();
        listTotalHarga = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        listKotakTotalHarga = new javax.swing.JList<>();
        listTotalBelanjaLabel = new javax.swing.JLabel();
        ttlBelanja = new javax.swing.JLabel();
        checkOut = new javax.swing.JButton();
        nomTtl = new javax.swing.JLabel();
        rupiah = new javax.swing.JLabel();
        nomTtl1 = new javax.swing.JLabel();
        nomTtl2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(716, 548));

        jLabel1.setFont(new java.awt.Font("ROG Fonts", 1, 14)); // NOI18N
        jLabel1.setText("Keranjang");

        listNamaBarang.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listNamaBarang);

        namaBarangLabel.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        namaBarangLabel.setText("Nama Barang");

        listKotakQuantity.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(listKotakQuantity);

        listQuantity.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        listQuantity.setText("Quantity");

        listKotakHarga.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(listKotakHarga);

        listHarga.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        listHarga.setText("Harga");

        listTotalHarga.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        listTotalHarga.setText("Total Harga");

        listKotakTotalHarga.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane4.setViewportView(listKotakTotalHarga);

        listTotalBelanjaLabel.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        listTotalBelanjaLabel.setText("Total Belanja");

        ttlBelanja.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        ttlBelanja.setText("Rupiah");

        checkOut.setBackground(new java.awt.Color(0, 153, 204));
        checkOut.setForeground(new java.awt.Color(255, 255, 255));
        checkOut.setText("Kembali");
        checkOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkOutActionPerformed(evt);
            }
        });

        nomTtl.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        nomTtl.setText("Rupiah");

        rupiah.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        rupiah.setText("Rupiah");

        nomTtl1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        nomTtl1.setText(":");

        nomTtl2.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        nomTtl2.setText(":");

        jButton1.setText("Pembayaran");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(listTotalBelanjaLabel)
                                    .addComponent(rupiah))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nomTtl1)
                                    .addComponent(nomTtl2))
                                .addGap(23, 23, 23)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(ttlBelanja)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(nomTtl)
                                        .addGap(140, 140, 140)
                                        .addComponent(checkOut, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                        .addGap(24, 24, 24))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(namaBarangLabel))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(listQuantity)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addComponent(listHarga))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addComponent(listTotalHarga)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane4)))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(78, 78, 78)
                        .addComponent(namaBarangLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(listHarga)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(listQuantity)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(listTotalHarga)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(listTotalBelanjaLabel)
                    .addComponent(ttlBelanja)
                    .addComponent(nomTtl2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nomTtl)
                    .addComponent(rupiah)
                    .addComponent(nomTtl1)
                    .addComponent(checkOut, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(101, 101, 101))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void checkOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkOutActionPerformed
        d1.show();
        dispose();
    }//GEN-LAST:event_checkOutActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Pembayaran bayar = new  Pembayaran();
        bayar.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton checkOut;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel listHarga;
    private javax.swing.JList<String> listKotakHarga;
    private javax.swing.JList<String> listKotakQuantity;
    private javax.swing.JList<String> listKotakTotalHarga;
    private javax.swing.JList<String> listNamaBarang;
    private javax.swing.JLabel listQuantity;
    private javax.swing.JLabel listTotalBelanjaLabel;
    private javax.swing.JLabel listTotalHarga;
    private javax.swing.JLabel namaBarangLabel;
    private javax.swing.JLabel nomTtl;
    private javax.swing.JLabel nomTtl1;
    private javax.swing.JLabel nomTtl2;
    private javax.swing.JLabel rupiah;
    private javax.swing.JLabel ttlBelanja;
    // End of variables declaration//GEN-END:variables

    
}
