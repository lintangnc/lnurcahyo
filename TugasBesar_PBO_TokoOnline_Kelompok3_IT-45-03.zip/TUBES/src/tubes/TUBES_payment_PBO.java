package tubes;

public class TUBES_payment_PBO {

    public static void main(String[] args) {
        payment payment1 = new payment(1, 101, "Credit Card", 50.0, new date(), "Success");
        payment payment2 = new payment(2, 102, "PayPal", 75.0, new date(), "Pending");

        System.out.println("Payment 1 Details:");
        System.out.println("PaymentID: " + payment1.getPaymentID());
        System.out.println("OrderID: " + payment1.getOrderID());
        System.out.println("PaymentMethod: " + payment1.getPaymentMethod());
        System.out.println("Amount: " + payment1.getAmount());
        System.out.println("PaymentDate: " + payment1.getPaymentDate());
        System.out.println("Status: " + payment1.getStatus());

        System.out.println("\nPayment 2 Details:");
        System.out.println("PaymentID: " + payment2.getPaymentID());
        System.out.println("OrderID: " + payment2.getOrderID());
        System.out.println("PaymentMethod: " + payment2.getPaymentMethod());
        System.out.println("Amount: " + payment2.getAmount());
        System.out.println("PaymentDate: " + payment2.getPaymentDate());
        System.out.println("Status: " + payment2.getStatus());
    }
    }
    
}
