import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Order {
    private int orderID;
    private int userID;
    private List<Product> products;
    private Date orderDate;
    private float totalPrice;
    private String status;
    private String deliveryAddress;

    public Order(int orderID, int userID, List<Product> products, Date orderDate, float totalPrice, String status, String deliveryAddress) {
        this.orderID = orderID;
        this.userID = userID;
        this.products = products;
        this.orderDate = orderDate;
        this.totalPrice = totalPrice;
        this.status = status;
        this.deliveryAddress = deliveryAddress;
    }

    // Getter methods
    public int getOrderID() {
        return orderID;
    }

    public int getUserID() {
        return userID;
    }

    public List<Product> getProducts() {
        return products;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public float getTotalPrice() {
        return totalPrice;
    }

    public String getStatus() {
        return status;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    // Calculate total price and update the total price field
    public void calculateTotalPrice() {
        float calculatedTotal = 0;
        for (Product product : products) {
            calculatedTotal += product.getPrice();
        }
        this.totalPrice = calculatedTotal;
    }

    // Add a product to the order
    public void addProduct(Product product) {
        products.add(product);
    }

    // Remove a product from the order
    public void removeProduct(Product product) {
        products.remove(product);
        calculateTotalPrice(); // Update total price after removal
    }

    // Change the status of the order
    public void changeStatus(String newStatus) {
        this.status = newStatus;
    }

    // Display order details
    public void displayOrderDetails() {
        System.out.println("Order ID: " + orderID);
        System.out.println("User ID: " + userID);
        System.out.println("Order Date: " + orderDate);
        System.out.println("Delivery Address: " + deliveryAddress);
        System.out.println("Total Price: " + totalPrice);
        System.out.println("Status: " + status);

        System.out.println("Products:");
        for (Product product : products) {
            System.out.println("- " + product.getName() + ": " + product.getPrice());
        }
    }

    // Inner Product class
    private static class Product {
        private String name;
        private float price;

        public Product(String name, float price) {
            this.name = name;
            this.price = price;
        }

        public String getName() {
            return name;
        }

        public float getPrice() {
            return price;
        }
    }
}
