package tubes;
import java.util.Date;

public class payment {
    private int paymentID;
    private int orderID;
    private String paymentMethod;
    private double amount;
    private Date paymentDate;
    private String status;
    
    public payment(int paymentID, int orderID, String paymentMethod, double amount, Date paymentDate, String status) {
        this.paymentID = paymentID;
        this.orderID = orderID;
        this.paymentMethod = paymentMethod;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.status = status;
    }
    
    public int getPaymentID() {
        return paymentID;
    }

    public int getOrderID() {
        return orderID;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public double getAmount() {
        return amount;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public String getStatus() {
        return status;
    }
}
